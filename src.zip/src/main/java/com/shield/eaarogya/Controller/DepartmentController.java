package com.shield.eaarogya.Controller;

import com.shield.eaarogya.Entity.Department;
import com.shield.eaarogya.Service.DepartmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/department")
public class DepartmentController {

    @Autowired
    private DepartmentService departmentService;

    // ------------------------------ Save a Department --------------------------------------
    @PostMapping("/saveDepartment")
    public Department saveDepartment(@RequestBody Department department) {
        return departmentService.saveDepartment(department);
    }

    // ---------------------------- Get all Departments -------------------------------------
    @GetMapping("/getDepartment")
    public List<Department> fetchDepartmentList() {
        return departmentService.fetchDepartmentList();
    }
}
