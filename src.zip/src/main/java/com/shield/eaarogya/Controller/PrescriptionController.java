package com.shield.eaarogya.Controller;

import com.shield.eaarogya.DAO.PrescriptionDetails;
import com.shield.eaarogya.Entity.Prescription;
import com.shield.eaarogya.Service.PrescriptionService;
import lombok.Getter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin("*")
@RequestMapping("/prescription")
public class PrescriptionController {

    @Autowired
    PrescriptionService prescriptionService;

    @GetMapping("/getPrescriptions/{patientId}")
    public List<PrescriptionDetails> getPrescriptions(@PathVariable String patientId) {
        return this.prescriptionService.getPrescriptions(Long.parseLong(patientId));
    }

    @GetMapping("/getAllPrescriptions")
    public List<PrescriptionDetails> getAllPrescriptions() {
        return this.prescriptionService.getAllPrescriptions();
    }

    @PostMapping("/addPrescription")
    public PrescriptionDetails addPrescription(@RequestBody PrescriptionDetails prescriptionDetails) {
        return this.prescriptionService.addPrescription(prescriptionDetails);
    }
}
