package com.shield.eaarogya.Service;

import com.shield.eaarogya.DAO.PatientDetails;
import com.shield.eaarogya.Entity.Patient;

import java.util.List;

public interface PatientService {

    // ------------------------- for Testing DAO layer -------------------------------
    public String testThis();

    public List<Patient> getPatient();

    public boolean addPatient(PatientDetails patientDetails);
}
