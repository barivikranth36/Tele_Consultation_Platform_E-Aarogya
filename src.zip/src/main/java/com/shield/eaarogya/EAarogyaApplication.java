package com.shield.eaarogya;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EAarogyaApplication {

    public static void main(String[] args)
    {
        SpringApplication.run(EAarogyaApplication.class, args);
        System.out.println("From our Application");
    }

}
