package com.shield.eaarogya.DAO;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import java.util.Date;

/*
    This Class is to merge the department and doctor data and transfer it through the API
*/

public class DoctorDepartment {

    private long dr_id;

    private String title;

    private String fName;

    private String lName;

    private String email;

    private String registration_number;

    @Temporal(TemporalType.DATE)
    private Date dob;

    private String gender;

    private String addr;

    private String city;

    private long pincode;

    private String dept_name;

//    private String description;

    // ---------------------------------- Constructors ----------------------------------


    public DoctorDepartment() {
    }

    public DoctorDepartment(int dr_id, String title, String fName, String lName, String email, String registration_number, Date dob, String gender, String addr, String city, long pincode, String dept_name) {
        this.dr_id = dr_id;
        this.title = title;
        this.fName = fName;
        this.lName = lName;
        this.email = email;
        this.registration_number = registration_number;
        this.dob = dob;
        this.gender = gender;
        this.addr = addr;
        this.city = city;
        this.pincode = pincode;
        this.dept_name = dept_name;
    }

    // ----------------------------------- Getters and Setters --------------------------------------


    public long getDr_id() {
        return dr_id;
    }

    public void setDr_id(long dr_id) {
        this.dr_id = dr_id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getfName() {
        return fName;
    }

    public void setfName(String fName) {
        this.fName = fName;
    }

    public String getlName() {
        return lName;
    }

    public void setlName(String lName) {
        this.lName = lName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getRegistration_number() {
        return registration_number;
    }

    public void setRegistration_number(String registration_number) {
        this.registration_number = registration_number;
    }

    public Date getDob() {
        return dob;
    }

    public void setDob(Date dob) {
        this.dob = dob;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getAddr() {
        return addr;
    }

    public void setAddr(String addr) {
        this.addr = addr;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public long getPincode() {
        return pincode;
    }

    public void setPincode(long pincode) {
        this.pincode = pincode;
    }

    public String getDept_name() {
        return dept_name;
    }

    public void setDept_name(String dept_name) {
        this.dept_name = dept_name;
    }

    // ------------------------------- toString() method -------------------------------


    @Override
    public String toString() {
        return "DoctorDepartment{" +
                "dr_id=" + dr_id +
                ", title='" + title + '\'' +
                ", fName='" + fName + '\'' +
                ", lName='" + lName + '\'' +
                ", email='" + email + '\'' +
                ", registration_number='" + registration_number + '\'' +
                ", dob='" + dob + '\'' +
                ", gender='" + gender + '\'' +
                ", addr='" + addr + '\'' +
                ", city='" + city + '\'' +
                ", pincode=" + pincode +
                ", dept_name='" + dept_name + '\'' +
                '}';
    }
}
