package com.shield.eaarogya.DAO;

import com.shield.eaarogya.Entity.Prescription;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import java.util.Date;
import java.util.List;

public class PatientDetails {

    private long patientId;

    private String title;

    private String fName;

    private String lName;

    private String gender;

    private long phoneNo;

    private String email;

    @Temporal(TemporalType.DATE)
    private Date dob;

    private String addr;

    private String city;

    private long pincode;

//    private List<Prescription> prescriptionList;
    // --------------------------------- Constructor ---------------------------------------

    public PatientDetails() {
    }

    public PatientDetails(long patientId, String title, String fName, String lName, String gender, long phoneNo, String email, Date dob, String addr, String city, long pincode) {
        this.patientId = patientId;
        this.title = title;
        this.fName = fName;
        this.lName = lName;
        this.gender = gender;
        this.phoneNo = phoneNo;
        this.email = email;
        this.dob = dob;
        this.addr = addr;
        this.city = city;
        this.pincode = pincode;
    }

    // ----------------------------------- Getters and Setters -------------------------------------

    public long getPatientId() {
        return patientId;
    }

    public void setPatientId(long patientId) {
        this.patientId = patientId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getfName() {
        return fName;
    }

    public void setfName(String fName) {
        this.fName = fName;
    }

    public String getlName() {
        return lName;
    }

    public void setlName(String lName) {
        this.lName = lName;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public long getPhoneNo() {
        return phoneNo;
    }

    public void setPhoneNo(long phoneNo) {
        this.phoneNo = phoneNo;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Date getDob() {
        return dob;
    }

    public void setDob(Date dob) {
        this.dob = dob;
    }

    public String getAddr() {
        return addr;
    }

    public void setAddr(String addr) {
        this.addr = addr;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public long getPincode() {
        return pincode;
    }

    public void setPincode(long pincode) {
        this.pincode = pincode;
    }

    // ------------------------------------ toString() method ---------------------------------------

    @Override
    public String toString() {
        return "PatientDetails{" +
                "patientId=" + patientId +
                ", title='" + title + '\'' +
                ", fName='" + fName + '\'' +
                ", lName='" + lName + '\'' +
                ", gender='" + gender + '\'' +
                ", phoneNo=" + phoneNo +
                ", email='" + email + '\'' +
                ", dob='" + dob + '\'' +
                ", addr='" + addr + '\'' +
                ", city='" + city + '\'' +
                ", pincode=" + pincode +
                '}';
    }
}
