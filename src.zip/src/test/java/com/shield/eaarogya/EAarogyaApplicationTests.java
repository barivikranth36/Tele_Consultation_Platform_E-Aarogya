package com.shield.eaarogya;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EAarogyaApplicationTests {

    @Test
    void contextLoads() {
    }

}
